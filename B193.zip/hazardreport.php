
<!DOCTYPE html>

<html>
<head>
 
    
   
    <meta charset="utf-8">
    <title>company Report</title>

      </head>
      <style type="text/css">

table
{
	 border-collapse: collapse;
}
       th, td {
    border: 1px solid black;
  
    vertical-align: text-top;
    
}
  
table .heading
{
 

  text-align: left;
  background-color: #868080;
  color:white;
 


}
.no_border
{
border:none;	
}
.no_border tr td 

{
border-left: 0px;
    border-right: 0px;
}
</style>

<body>
    <div class="container">
   
<table style="width:100%">
 <thead>
       <tr>
       <th style="text-align:left;">Department</th>
       <th style="text-align:left;">QE Elemech Engineering / Maintenance</th>
       <th style="text-align:left;">RA Leader: Julius Lim</th>
       <th style="text-align:left" rowspan="3">Approved by:Signature</th>
       <th style="text-align:left" rowspan="3"></th>
       <th style="text-align:left" rowspan="6">Reference Number</th>
       </tr>

       <tr>
       <th style="text-align:left;">Process</th>
       <th style="text-align:left;">Servicing of Hydraulic Door Drive System</th>
       <th style="text-align:left;">RA Member 1: Chong How</th>
      
       </tr>
        <tr>
       <th style="text-align:left;">Process / Activity Locatio</th>
       <th style="text-align:left;">CAB PDS</th>
       <th style="text-align:left;">RA Member 2: Maung Than Lan Tuang</th>
       </tr>

       <tr>
       <th style="text-align:left;">Original Assessment Date</th>
       <th style="text-align:left;">31-Mar-11</th>
       <th style="text-align:left;">RA Member 3: </th>
        <th style="text-align:left;">Name</th>
        <th style="text-align:left;"> Amos Ang</th>
       
       </tr>

        <tr>
       <th style="text-align:left;">Last Review Date:</th>
       <th style="text-align:left;">30-Jun-15</th>
       <th style="text-align:left;">RA Member 4: </th>
        <th style="text-align:left;">Designation</th>
        <th style="text-align:left;">Manager</th>
       
       </tr>
        <tr>
       <th style="text-align:left;">Next Review Dat</th>
       <th style="text-align:left;">29-Jun-18</th>
       <th style="text-align:left;">RA Member 5:: </th>
        <th style="text-align:left;">Date</th>
        <th style="text-align:left;">30-Jun-15</th>
      
       </tr>
                <tr  class="heading">
                <th style="text-align:center;" colspan="2">Hazard Identification</th>
                <th style="text-align:center;" colspan="2">Risk Evaluation</th>
                <th style="text-align:center;" colspan="2">Risk Control</th>
           </tr>

             

        </thead>
        <tbody id="myTable">
        </tbody>
        
      
       <tr> 

        <td>01</td>
        <td>Kolkata</td>
        <td>Servicing of Hydraulic Door Drive System</td>
        </tr>
        	
         
    </tbody>
    </table>
    </div>
       <div style="margin: 0 auto; width: 656px; text-align: center;"><button>Print</button></div>
    </body>
    </html>
    